import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class Week6LabProblem1 extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        Group root = new Group();
        Scene scene = new Scene(root, 500, 500);

        final double width = scene.getWidth();
        final double height = scene.getHeight();
        final int step = 10;

        // Your code here :)

        scene.setFill(Color.BLACK);

        primaryStage.setTitle("Problem 1: Astroid with Four Cusps");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
